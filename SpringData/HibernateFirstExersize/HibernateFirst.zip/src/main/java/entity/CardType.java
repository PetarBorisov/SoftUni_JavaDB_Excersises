package entity;

public enum CardType {
    GOLD, SILVER
}
