package com.example.xml.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
