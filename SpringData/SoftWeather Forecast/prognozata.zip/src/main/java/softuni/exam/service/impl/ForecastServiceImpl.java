package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.Messages;
import softuni.exam.models.dto.ForecastSeedDto;
import softuni.exam.models.dto.ForecastSeedRootDto;
import softuni.exam.models.entity.City;
import softuni.exam.models.entity.Forecast;
import softuni.exam.repository.CityRepository;
import softuni.exam.repository.ForecastRepository;
import softuni.exam.service.ForecastService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ForecastServiceImpl implements ForecastService {
    private static final String FORECAST_FILE_PATH = "src/main/resources/files/xml/forecasts.xml";

    private final ForecastRepository forecastRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;
    private final CityRepository cityRepository;


    public ForecastServiceImpl(ForecastRepository forecastRepository, ModelMapper modelMapper, ValidationUtil validationUtil, XmlParser xmlParser, CityRepository cityRepository) {
        this.forecastRepository = forecastRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.xmlParser = xmlParser;
        this.cityRepository = cityRepository;
}

    @Override
    public boolean areImported() {
        return forecastRepository.count() > 0;
    }

    @Override
    public String readForecastsFromFile() throws IOException {
        return Files.readString(Path.of(FORECAST_FILE_PATH));
    }

    @Override
    public String importForecasts() throws IOException, JAXBException {
        
        StringBuilder sb = new StringBuilder();
        final List<ForecastSeedDto> forecasts = this.xmlParser
                .fromFile(Path.of(FORECAST_FILE_PATH).toString(), ForecastSeedRootDto.class)
                .getForecasts();

        for (ForecastSeedDto forecast : forecasts) {
            sb.append(System.lineSeparator());

            if (this.validationUtil.isValid(forecast)) {
                final Optional<City> city =
                        this.cityRepository.findById(forecast.getCity());
                if (!city.isPresent()) {
                    continue;
                }
                final Forecast forecast1 = this.modelMapper.map(forecast, Forecast.class);
                forecast1.setCity(city.get());

                this.forecastRepository.save(forecast1);
                sb.append(String.format("Successfully import forecast %s - %.2f",
                        forecast.getDayOfWeek(),forecast.getMaxTemperature()));
                continue;
            }
            sb.append(String.format("Invalid forecast"));
        }


        return sb.toString().trim();
    }


    @Override
    public String exportForecasts() {
        return null;
    }
}
