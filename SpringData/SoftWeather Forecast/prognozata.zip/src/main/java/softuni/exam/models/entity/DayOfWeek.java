package softuni.exam.models.entity;

public enum DayOfWeek {
    FRIDAY,SATURDAY,SUNDAY
}
