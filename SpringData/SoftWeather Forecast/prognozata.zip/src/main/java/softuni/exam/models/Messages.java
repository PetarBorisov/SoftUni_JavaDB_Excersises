package softuni.exam.models;

public enum Messages {
    ;
    public static final String INVALID_COUNTRY = "Invalid country%n";
    public static final String VALID_COUNTRY_FORMAT = "Successfully imported country %s - %s%n";
    public static final String VALID_CITY_FORMAT = "Successfully imported city %s - %d";
    public static final String INVALID_CITY = "Successfully imported city";
    public static final String Valid_Forecast = "Successfully imported forecast %s - %.2f";
    public static final String Invalid_Forecast = "Invalid forecast";


}
